const Income=require('../models/income')

exports.Incomeform=(req,res)=>{
    try{
  const{income,date,category,amount}=req.body
  const record=new Income({ Income:income,Expenses:amount,ExpenseDate:date,Category:category})
  record.save()
  res.json({
    status:201,
    apiData:record,
    message:'Data added'
   })
  }catch(error){
    res.json({
        status:400,
        message:error.message
    })
  }
}

exports.Incomedata=async(req,res)=>{
  try{
    const record=await Income.find()
    res.json({
     status:200,
     apiData:record
    })
  }catch(error){
    res,json({
      status:500,
      message:error.message
    })
  }
  
}

exports.incomeupdate=async(req,res)=>{
  try{
    const id=req.params.id
    const {income}=req.body
    await Income.findByIdAndUpdate(id,{Income:income})
    res.json({
      status:200,
      message:"Successfully Updated"
    })
  }catch(error){
    res.json({
      status:400,
      message:error.message
    })
  }
 
}