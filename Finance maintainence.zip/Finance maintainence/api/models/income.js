const mongoose=require('mongoose')

const incomeSchema=mongoose.Schema({
  Income:Number,
  Expenses:Number,
  ExpenseDate:Date,
  Category:String
})

 module.exports=mongoose.model('income',incomeSchema)