const mongoose=require('mongoose')

const regSchema=mongoose.Schema({
    Fname:String,
    Lname:String,
    Email:String,
    Mobile:Number,
    Password:String,
})

 module.exports=mongoose.model('reg',regSchema)