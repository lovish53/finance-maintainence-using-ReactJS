const router=require("express").Router();
const regc=require('../controllers/regccontroller');
const incomec= require('../controllers/incomecontroller')

router.post('/',regc.register)
router.post('/login',regc.login)
router.post('/incomeform',incomec.Incomeform)
router.get('/incomedata',incomec.Incomedata)
router.put('/incomeupdate/:id',incomec.incomeupdate)


module.exports= router