import { BrowserRouter as Router, Route, Routes} from "react-router-dom"
import { useState } from "react";
import Registration from "./Components/Registration";
import Login from "./Components/Login";
import { Contextapi } from './Components/Contextapi';
import Incomeform from "./Components/Incomeform";
import Incomedata from "./Components/Incomedata";
import Incomeupdate from "./Components/Incomeupdate";


function App() {
    const[loginname,setLoginname]=useState(localStorage.getItem('loginname'))
    const[remainingAmount,setRemainingAmount]=useState("")
    const[id,setID]=useState('')
  return (
    <Router>
     <Contextapi.Provider value={{loginname,setLoginname,remainingAmount,setRemainingAmount,id,setID}}>
    <Routes>
        <Route path="/" element={<Registration/>}></Route>
        <Route path="/login" element={<Login/>}></Route>
        <Route path="/incomeform" element={<Incomeform/>}></Route>
        <Route path="/incomedata" element={<Incomedata/>}></Route>
        <Route path="/incomeupdate/:id" element={<Incomeupdate/>}></Route>
    </Routes>
    </Contextapi.Provider>
</Router>

    );
}

export default App;
