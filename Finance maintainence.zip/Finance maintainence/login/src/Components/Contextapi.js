import { createContext} from 'react'




 export let Contextapi=createContext(null)