import { useEffect, useState, useContext } from "react";
import{Link, useNavigate} from "react-router-dom"
import{Contextapi} from "./Contextapi"

function Incomedata() {
  const [incomedata, setIncomedata] = useState([])
  const [income, setIncome] = useState('')
  const [message, setMessage] = useState('')
  const [firstID,setFirstID]=useState('')
  const navigate=useNavigate()
  const{setRemainingAmount,setID,loginname, setLoginname} =useContext(Contextapi)
  let totalExpense = 0
  let remain=0
  useEffect(() => {
    fetch('/incomedata').then((result) => { return result.json() }).then((data) => {
      console.log(data)
      if (data.status === 200) {
        setIncomedata(data.apiData)
        setIncome(data.apiData[0].Income)
        setFirstID(data.apiData[0]._id)
        setID(data.apiData[0]._id)
      } else {
        setMessage(data.message)
      }
    })
  }, [])
  function handlelogout(e){
    localStorage.removeItem('loginname')
    setLoginname(localStorage.getItem('loginname'))
    navigate('/')
  }
  
  return (
    <section id="income-data">
      <div className="container">
        <div className="row">
          <div className="col-md-12 mt-5">
            {loginname?<>
              <div className="d-flex">
                <p>{loginname}</p>
                <button onClick={(e)=>{handlelogout(e)}} className="btn btn-danger ms-auto">Log out</button>
                </div>
            <div className="d-flex mb-5">
              <p>{message}</p>
              <h1>Income:{income} INR</h1>
              <Link to={`/incomeupdate/${firstID}`}><p className="mt-3 ms-2">Update</p></Link>
              {incomedata.map((result)=>{
                <div key={result._id}>
                  {totalExpense += result.Expenses}
                </div>
              })}
              {income - totalExpense<=0?
              <h1 className="mx-auto">You are broke</h1>
              :
              <></>
              }
              <div className="ms-auto"><h1>Current balance:{income - totalExpense} INR</h1>
              </div>
              <p style={{color:"white"}}>{remain=income - totalExpense}</p>
              {setRemainingAmount(remain)}
            </div>
            <div>
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th>S.no</th>
                    <th>Date</th>
                    <th>Category</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {incomedata.map((result, key) => (
                    <tr key={result._id}>
                      <td>{key + 1}</td>
                      <td>{result.ExpenseDate}</td>
                      <td>{result.Category}</td>
                      <td>{result.Expenses} INR</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
</>
:
<>
</>
}
          </div>
        </div>
      </div>
    </section>
  );
}

export default Incomedata;