import { useState, useContext } from "react"
import {Link, useNavigate,useParams} from "react-router-dom"
import {Contextapi} from './Contextapi'
function Incomeform() {
 const[income,setIncome] =  useState('')
 const[date,setDate] =  useState('')
 const[category,setCategory] =  useState('')
 const[amount,setAmount] =  useState('')
 const[message,setMessage]=useState('')
 const navigate=useNavigate()
const{remainingAmount,id,setLoginname,loginname}=useContext(Contextapi)
function handleIncome(e){
    e.preventDefault()
    const data={income,date,category,amount}
    //console.log(data)
    fetch('/incomeform',{
         method:"POST",
       headers:{"Content-Type":"application/json"},
       body:JSON.stringify(data)
    }).then((result)=>{return result.json()}).then((data)=>{
        if(data.status===201){
             setMessage("Data Added Successfully")
             navigate('/incomedata')
        }else{
            setMessage(data.message)
        }
    })
}
function handlelogout(e){
    localStorage.removeItem('loginname')
    setLoginname(localStorage.getItem('loginname'))
    navigate('/')
  }
    return ( 
        <section id="incomeform">
        <div className="container">
            <div className="row">
                <div className="col-md-12">  
                {loginname?<>
                    <div className="incomeform-heading"> 
                <h1>Add Data Here!!</h1>

                <div className="d-flex">
                <p>{loginname}</p>
                <button onClick={(e)=>{handlelogout(e)}} className="btn btn-danger ms-auto">Log out</button>
                </div>
                <p>{message}</p>
                <p>If income is already added no need to add it again. You can update it from display board</p>
                </div>
                <form className="incomeform form-control" onSubmit={(e)=>{handleIncome(e)}}>
                <label>Income</label>
                <input type="number" className="form-control"
                 value={income}
                 onChange={(e)=>{setIncome(e.target.value)}}
                ></input>
                <label>Date</label>
                <input type="date" className="form-control"
                value={date}
                onChange={(e)=>{setDate(e.target.value)}} required                
                ></input>
                <label>Category</label>
                <input type="text" className="form-control"
                value={category}
                onChange={(e)=>{setCategory(e.target.value)}} required   
                ></input>
                <label>Amount</label>
                <input type="number" className="form-control"
                value={amount}
                onChange={(e)=>{setAmount(e.target.value)}} required   
                ></input>
                <button type="submit" className="btn btn-outline-primary mt-2 mb-2">Submit</button>
             </form>
             </>
             :
             <>
             </>
             }
                </div>
            </div>
        </div>
             
        </section>
            
     );
}

export default Incomeform;