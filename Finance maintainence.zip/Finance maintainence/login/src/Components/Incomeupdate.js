import{Link, useParams, useNavigate} from "react-router-dom"
import {useEffect, useState, useContext} from "react"
import {Contextapi}  from './Contextapi'  

function Incomeupdate() {
   const[income,setIncome]= useState('')
   const[message,setMessage]=useState('')
  const {id}= useParams()
  const{loginname}=useContext(Contextapi)
  const navigate=useNavigate()

    function handleUpdate(e){
        e.preventDefault()
        const data={income}
        fetch(`/incomeupdate/${id}`,{
            method:"PUT",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(data)
        }).then((result)=>{return result.json()}).then((data)=>{
            if(data.status===200){
                setMessage(data.message)
                navigate('/incomedata')
            }else{
                setMessage(data.message)
            }
        })
    }
    return ( 
        <section id="income-update">
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                {loginname?<>
                <h1>Update Your Income here!!</h1>
                <p>{message}</p>
                <form className="form-control" onSubmit={(e)=>{handleUpdate(e)}}>
                <label>Income</label>
                  <input type="number" className="form-control"
                  value={income}
                  onChange={(e)=>{setIncome(e.target.value)}}
                  ></input>
                  <button type="submit" className="btn btn-primary mt-2 mb-2">Change</button>
                </form>
                </>
                :
                <></>
                }
                </div>
            </div>
        </div>
                  
        </section>
       
     );
}

export default Incomeupdate;